﻿namespace TicTac
{
    public enum WinType
    {
        Row, Column, MainDiagonal, AntiDiagonal 
    }
}
