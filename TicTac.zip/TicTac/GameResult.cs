﻿namespace TicTac
{
    public class GameResult
    {
        public player Winner { get; set; }
        public WinInfo WinInfo { get; set; }

    }
}
