﻿namespace TicTac
{
    public enum player
    {
        None, X, O
    }
}
